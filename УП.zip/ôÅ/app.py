import os
import sqlite3
import datetime

from flask import Flask, g, redirect, render_template, request, url_for, send_from_directory

app = Flask(__name__)
DB = "equipment.db"
BACKUP_DIR = "backups"

TYPES = ["Компьютер", "Ноутбук", "Монитор", "Принтер", "Проектор", "Другое"]
STATUSES = ["Исправна", "В ремонте", "Списана"]
FIELDS = ["inv", "name", "type", "room", "person", "date", "status"]


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(exc=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    with sqlite3.connect(DB) as db:
        db.execute(
            """CREATE TABLE IF NOT EXISTS equipment (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                inv TEXT NOT NULL UNIQUE,
                name TEXT NOT NULL,
                type TEXT NOT NULL,
                room TEXT,
                person TEXT,
                date TEXT,
                status TEXT NOT NULL
            )"""
        )


def read_form():
    return {f: request.form.get(f, "").strip() for f in FIELDS}


def validate(data, item_id=None):
    if not data["inv"] or not data["name"]:
        return "Укажите инвентарный номер и наименование."
    if data["type"] not in TYPES or data["status"] not in STATUSES:
        return "Некорректный тип или состояние."
    row = get_db().execute(
        "SELECT id FROM equipment WHERE inv = ? AND id IS NOT ?",
        (data["inv"], item_id),
    ).fetchone()
    if row:
        return "Техника с таким инвентарным номером уже есть."
    return None


def list_backups():
    if not os.path.isdir(BACKUP_DIR):
        return []
    files = [f for f in os.listdir(BACKUP_DIR) if f.endswith(".db")]
    return sorted(files, reverse=True)


def page(form=None, edit_id=None, error=None):
    q = request.args.get("q", "").strip().lower()
    status = request.args.get("status", "")
    rows = get_db().execute("SELECT * FROM equipment ORDER BY inv").fetchall()
    counts = {s: sum(1 for r in rows if r["status"] == s) for s in STATUSES}
    total = len(rows)
    if status:
        rows = [r for r in rows if r["status"] == status]
    if q:
        rows = [
            r for r in rows
            if q in " ".join([r["inv"], r["name"], r["room"] or "", r["person"] or ""]).lower()
        ]
    return render_template(
        "index.html", rows=rows, form=form or {}, edit_id=edit_id, error=error,
        types=TYPES, statuses=STATUSES, counts=counts, total=total, q=q, status=status,
        backups=list_backups(),
        backup_msg=request.args.get("backup"),
        backup_err=request.args.get("error"),
    )


@app.route("/")
def index():
    return page()


@app.route("/add", methods=["POST"])
def add():
    data = read_form()
    error = validate(data)
    if error:
        return page(form=data, error=error)
    db = get_db()
    db.execute(
        "INSERT INTO equipment (inv, name, type, room, person, date, status) VALUES (?,?,?,?,?,?,?)",
        [data[f] for f in FIELDS],
    )
    db.commit()
    return redirect(url_for("index"))


@app.route("/edit/<int:item_id>", methods=["GET", "POST"])
def edit(item_id):
    db = get_db()
    item = db.execute("SELECT * FROM equipment WHERE id = ?", (item_id,)).fetchone()
    if item is None:
        return redirect(url_for("index"))
    if request.method == "GET":
        return page(form=dict(item), edit_id=item_id)
    data = read_form()
    error = validate(data, item_id)
    if error:
        return page(form=data, edit_id=item_id, error=error)
    db.execute(
        "UPDATE equipment SET inv=?, name=?, type=?, room=?, person=?, date=?, status=? WHERE id=?",
        [data[f] for f in FIELDS] + [item_id],
    )
    db.commit()
    return redirect(url_for("index"))


@app.route("/delete/<int:item_id>", methods=["POST"])
def delete(item_id):
    db = get_db()
    db.execute("DELETE FROM equipment WHERE id = ?", (item_id,))
    db.commit()
    return redirect(url_for("index"))


@app.route("/backup", methods=["POST"])
def backup():
    os.makedirs(BACKUP_DIR, exist_ok=True)
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    backup_name = f"equipment_{timestamp}.db"
    backup_path = os.path.join(BACKUP_DIR, backup_name)
    try:
        src = sqlite3.connect(DB)
        dst = sqlite3.connect(backup_path)
        with dst:
            src.backup(dst)
        src.close()
        dst.close()
    except Exception as e:
        return redirect(url_for("index", error=f"Ошибка резервного копирования: {e}"))
    return redirect(url_for("index", backup=backup_name))


@app.route("/backup/download/<path:filename>")
def download_backup(filename):
    return send_from_directory(BACKUP_DIR, filename, as_attachment=True)


init_db()

if __name__ == "__main__":
    app.run(debug=True)